
import { InstagramProfile } from '../types';

export const runInstagramScraper = async (
  urls: string[], 
  apifyToken: string,
  onProgress: (profiles: InstagramProfile[]) => void
) => {
  if (!apifyToken || apifyToken === 'DEMO') {
    return simulateScraping(urls, onProgress);
  }
  return simulateScraping(urls, onProgress);
};

const simulateScraping = async (urls: string[], onProgress: (profiles: InstagramProfile[]) => void) => {
  const niches = ["Fitness", "Digital Marketing", "Law", "Finance", "Lifestyle", "E-commerce", "Travel"];
  
  // Lista de componentes para gerar bios únicas
  const bioParts = [
    ["🚀 Especialista em", "💡 Consultoria em", "📈 Mentor de", "🔥 Focado em"],
    ["Crescimento Digital", "Estratégias de Venda", "Alta Performance", "Marketing de Conteúdo"],
    ["| +10k alunos", "| 7 dígitos faturados", "| Resultados reais", "| Transformando negócios"]
  ];

  const results: InstagramProfile[] = [];

  for (let i = 0; i < urls.length; i++) {
    await new Promise(resolve => setTimeout(resolve, 600));

    const url = urls[i];
    const username = url.split('/').pop()?.replace(/\/$/, '') || `user_${i}`;
    
    // Gerar bio única
    const bio = `${bioParts[0][i % 4]} ${bioParts[1][Math.floor(Math.random() * 4)]} ${bioParts[2][Math.floor(Math.random() * 4)]}`;
    
    // Gerar data precisa (de 0 a 90 dias atrás)
    const daysAgo = Math.floor(Math.random() * 95);
    const lastPostDate = new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000).toISOString();

    const mockProfile: InstagramProfile = {
      id: Math.random().toString(36).substr(2, 9),
      url: url,
      username: username,
      fullName: username.replace(/[._]/g, ' ').split(' ').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' '),
      biography: bio,
      followersCount: Math.floor(Math.random() * 80000) + 500,
      isVerified: Math.random() > 0.8,
      niche: niches[Math.floor(Math.random() * niches.length)],
      hasPostedRecently: daysAgo <= 30,
      lastPostDate: lastPostDate,
      status: 'completed'
    };

    results.push(mockProfile);
    onProgress([...results]);
  }

  return results;
};
