
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeProfileNiche = async (fullName: string, bio: string): Promise<string> => {
  if (!process.env.API_KEY) return "Uncategorized";

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze this Instagram profile and return a single-word or short phrase representing their niche. 
      Name: ${fullName}
      Bio: ${bio}
      Example niches: Fitness, Law, Digital Marketing, E-commerce, Lifestyle, Finance.`,
      config: {
        maxOutputTokens: 20,
        temperature: 0.1,
      },
    });

    return response.text?.trim() || "General";
  } catch (error) {
    console.error("Gemini analysis failed:", error);
    return "Analysis Failed";
  }
};

export const batchAnalyzeNiches = async (profiles: { fullName: string; bio: string }[]) => {
  if (!process.env.API_KEY) return profiles.map(() => "Uncategorized");

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Categorize the following Instagram profiles into niches based on their names and bios. 
      Input: ${JSON.stringify(profiles)}
      Return a JSON array of strings corresponding to each profile's niche.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });

    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Batch Gemini analysis failed:", error);
    return profiles.map(() => "General");
  }
};
