
import { createClient } from '@supabase/supabase-js';
import { InstagramProfile } from '../types';

const SUPABASE_URL = 'https://owyaewqdehhparheemdd.supabase.co';
const SUPABASE_KEY = 'sb_publishable_ZeUXimuvfY2SeeYCelr3kA_39Hq3uO6';

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

export const saveLeadsToDB = async (profiles: InstagramProfile[]) => {
  const dataToSave = profiles.map(p => ({
    url: p.url,
    username: p.username,
    full_name: p.fullName,
    bio: p.biography, // Alterado de 'biography' para 'bio' para coincidir com o provável nome da coluna no DB
    followers_count: p.followersCount,
    is_verified: p.isVerified,
    niche: p.niche,
    has_posted_recently: p.hasPostedRecently,
    last_post_date: p.lastPostDate,
  }));

  const { error } = await supabase
    .from('insta_leads')
    .upsert(dataToSave, { onConflict: 'url' });

  if (error) {
    console.error('Erro ao salvar no Supabase:', error.message || error);
    if (error.message?.includes('column')) {
      console.warn('Verifique se os nomes das colunas na tabela "insta_leads" coincidem com: url, username, full_name, bio, followers_count, is_verified, niche, has_posted_recently, last_post_date');
    }
  }
  return !error;
};

export const fetchLeadsFromDB = async (): Promise<InstagramProfile[]> => {
  const { data, error } = await supabase
    .from('insta_leads')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Erro ao buscar do Supabase:', error.message || error);
    return [];
  }

  return data.map(row => ({
    id: row.id,
    url: row.url,
    fullName: row.full_name,
    username: row.username,
    biography: row.bio || row.biography || '', // Suporta tanto 'bio' quanto 'biography' se existirem
    followersCount: Number(row.followers_count),
    isVerified: row.is_verified,
    niche: row.niche,
    hasPostedRecently: row.has_posted_recently,
    last_post_date: row.last_post_date,
    status: 'completed'
  }));
};
